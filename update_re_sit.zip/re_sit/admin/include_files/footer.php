 
<hr/>
 <footer class="footer">
          
            <div class="copy text-center">
              BIDA STANDARD<a href='#'>Website</a>
            </div>
            
       </footer>

  </body>


    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://code.jquery.com/jquery.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="bootstrap/js/bootstrap.min.js"></script>
    <script src="js/custom.js"></script>

</html>
