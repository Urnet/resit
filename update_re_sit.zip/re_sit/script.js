<!--image header-->
<header class="w3-display-container w3-wide" id="home">
    <img class="w3-image" src="C:\Users\TONY.hp\Desktop\website\h.jpg" alt="school picture" width="1600" height="1060">
    <div class="w3-display-left w3-padding-large">
    </div>
</header>    