<div class="col-md-2">
		  	<div class="sidebar content-box" style="display: block;">
                <ul class="nav">
                    <!-- Main menu -->
                    <li class="current"><a href="index.php"><i class="glyphicon glyphicon-home"></i> Dashboard</a></li>
                    <!-- <li><a href="calendar.html"><i class="glyphicon glyphicon-calendar"></i> Calendar</a></li> -->
                    <li><a href="registered.php"><i class="glyphicon glyphicon-stats"></i>Registered_Candidate</a></li>
                    <li><a href="courses.php"><i class="glyphicon glyphicon-stats"></i>Registered_Courses</a></li>
                    <!-- <li><a href="tables.html"><i class="glyphicon glyphicon-list"></i> Tables</a></li> -->
                    <!-- <li><a href="guide.php"><i class="glyphicon glyphicon-record"></i> Guide</a></li> -->
                    <!-- <li><a href="editors.html"><i class="glyphicon glyphicon-pencil"></i> Editors</a></li> -->
                    <li><a href="pay.php"><i class="glyphicon glyphicon-tasks"></i>pay for course</a></li>
                    <li class="submenu">
                         <a href="#">
                            <i class="glyphicon glyphicon-list"></i> Pages
                            <span class="caret pull-right"></span>
                         </a>
                         <!-- Sub menu -->
                         <ul>
                            <li><a href="#">profile</a></li>
                            <li><a href="../include_files/logout.php">Sign Out</a></li>
                        </ul>
                    </li>
                </ul>
		  </div>
</div>