

<div class="header" style="color: navy;">
            <center><h1><b>
                ONLINE RE-SIT REGISTRATION PORTAL</b>
            </h1>
        <h4><b>
            SCHOOL OF NURSING BIDA
        </b></h4>
        </center></div>