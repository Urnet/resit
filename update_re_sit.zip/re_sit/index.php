
<!-- header -->
<?php include "include_files/header.php";?>
<?php include "include_files/head.php";?>

  <div class="bgimg">
    <!-- Navigation -->
<?php include "include_files/navigation.php";?>

  


 <center><img src="l.png" alt="logo" width="300px" height="300px" >
        </center>
        <center>
            <!-- <H2 style="color: white;">LOGIN AS</H2> -->
                      <button class=" btn btn-primary"
            onclick="document.location='s_login.php'">LOGIN</button>
        </center> 


<?php include "include_files/footer.php";?>
</div> 